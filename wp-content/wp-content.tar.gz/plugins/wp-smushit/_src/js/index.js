import '@wpmudev/shared-ui';

console.log('This is the entry point.');
