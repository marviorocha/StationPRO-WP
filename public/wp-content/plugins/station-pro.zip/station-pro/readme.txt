=== Station Pro Plugin ===
Contributors: Marvio Rocha marviorocha.com
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=V7R7EKZBXWVVC
Tags: station pro, radio, station, streaming, shoutcast, live, online radio station, wordpress, plugin podcast
Requires at least: 3.5.1
Tested up to: 5.8
Stable tag: 2.2.2
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Welcome plugin Station Pro, for wordpress! That is plugin professional online web radio included a 
responsive navbar where you can setting in top or buttom. That is easy create automation web with Station Pro on your blog/site.

== Description ==

Now in its newest version the station Pro has more features and is compatible with most browsers and mobile device with a new technology for easily play in your radio station.
Now you can customize your Player yourself through wordpress!

Now it's easy to have your radio station where you'll install your URL and let Station Pro work for you with a simple, fast and functional touch!

 [**Demo**](https://stationpro.co/)
 

= Including: =

* Security listen
* Support player: Windows Media, Winamp, Android, iTunes and HTML5
* Players Theme settings
* Responsive player support (mobile)
* logfiles
* multi language ability
* uninstall routine
* data delete routine (avoid orphaned data)
* coding advices
 

The Station Pro player radio help your site with good audience. 
That is very simple make a broadcast and optimized for visit in your web site.  

== We recommend you use that premium version that including:== 

- Change color of player
- $ Ads code for you monetize
- Station analytics
- Schandule integrete 
- Free video tutorial (Secret how to make a server cast )
- No brand e link and banner 

==  Get version premium == 
 [**http://stationpro.marviorocha.com/**](http://stationpro.marviorocha.com)
 

*  
= Translators & Non-English Speakers =
We need your help to translate Station PRO into your language. If you have created your own language pack, or have an update of an existing one, you can post [gettext PO and MO files]

= Current Translations =

Special thanks to the following people for language translations.

 
= Get Involved =
 
cool!

== Installation ==

= Install the Plugin =
1. Upload the "redux-framework" directory to "~/wp-content/plugins/".
2. Activate the plugin through the "Plugins" area in WordPress admin panel.

 

= Start Building Your Own Panel =

1. Copy the "~/station-pro/" directory from within the plugin to a directory within your own theme or plugin.
2. Click on "Station PRO" in the "Plugins" area of the WordPress admin panel
.


= For Complete Support get Premium Version =
Visit: [http://marviorocha.com/stationpro](http://marviorocha.com/)



== Frequently Asked Questions ==

- Put your Shoutcast url with trach in end your url ex: http://www.myserver.com/


= Why doesn't this plugin do anything? =

Redux is an options framework... in other words, it's not designed to do anything on its own! You can however activate a demo mode to see how it works. 

 

= You don't have much content in this FAQ section =


== Screenshots ==


1. Front end Station PRO
2. Back end welcome page
3. Backend skyns selection playwer for your radio station



== Changelog ==

= Aug 21, 2021 =
* Components fix
* Build of svelte
* Fix class of player
* Added svelte for howler working
* Update components fix bugs
* New metadata for player
* Image to preloading

= May 20, 2021 =
* Added README for this branch
 
* Deleted the older wordpress
 
* New wordpress with LEMP
 
 
= Feb 8, 2021  =
* Added metadata to player


 
 
 

= Jan 30, 2021 =
* webpacker to plugin now with jquery

 

* added plugin with webpacker



 

= Jan 29, 2021 =
* update backend the plugin



 

= Jan 28, 2021 =
* new plugin code with piklist framework



 

= Jan 7, 2021 =


 

* Install Wordpress with Docker-Compose


* update player the Station Pro

* update player with tailwindcss framework


 

= Sep 25, 2020 =
* Add player icon

 
 
= 0.1.1.2 (03.03.2011) =
* adding submenus

= 0.1.1.1 (24.02.2011) =
* small bugfix
* testing on Wordpress 3.1

= 0.1.1 (22.02.2011) =
* logfile handling

= 1.6.(17.02.2011) =
* first stavel version

= 2.6.(19.05.2017) =
* beta free version Station Pro

= 2.1.7 (22.05.2017) =
* Security url update plugin

= 2.1.8 (11.06.2018) =
* Greatest update and customization of the player for radio now with podcast for premium user

= 2.2.0 (25.08.2019) =
* New version with fix code problem and new ajax loading only in premium code.

= 2.2.1 (28.08.2019) =
* Fix path url with wordpress plugin variable.

== Upgrade Notice ==

Just do a normal upgrade.

== To do ==

More translations. Does someone wants to help?

